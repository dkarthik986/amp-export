package com.swift.platform.model;

public enum ExportJobStatus {
    QUEUED,
    PROCESSING,
    COMPLETED,
    FAILED
}
